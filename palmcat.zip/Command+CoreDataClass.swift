//
//  Command+CoreDataClass.swift
//  
//
//  Created by Junsung Park on 2020/11/19.
//
//

import Foundation
import CoreData

@objc(Command)
public class Command: NSManagedObject {

}
