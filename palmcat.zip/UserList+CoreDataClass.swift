//
//  UserList+CoreDataClass.swift
//  
//
//  Created by Junsung Park on 2020/11/19.
//
//

import Foundation
import CoreData

@objc(UserList)
public class UserList: NSManagedObject {

}
